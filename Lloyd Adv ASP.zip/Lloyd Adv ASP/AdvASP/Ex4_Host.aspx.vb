﻿
Partial Class Ex4_Host
    Inherits System.Web.UI.Page

End Class

﻿
Partial Class Ex1_LinksHost
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Ex1_Links1.lb1Text = "EBAY"
        Ex1_Links1.lb1URL = "http://www.ebay.com"

        Ex1_Links1.lb2Text = "AMAZON"
        Ex1_Links1.lb2URL = "http://www.amazon.com"

        Ex1_Links1.lb3Text = "ESPN"
        Ex1_Links1.lb3URL = "http://www.espn.com"

        Ex1_Links1.lb4Text = "LIFE"
        Ex1_Links1.lb4URL = "http://www.lifeleadership.com"
    End Sub
End Class

﻿
Partial Class Ex3_Host
    Inherits System.Web.UI.Page

    Protected Sub btn1_Click(sender As Object, e As System.EventArgs) Handles btn1.Click
        txt1.style1()
    End Sub

    Protected Sub btn2_Click(sender As Object, e As System.EventArgs) Handles btn2.Click
        txt1.style2()
    End Sub
End Class

﻿
Partial Class ucCityTemp
    Inherits System.Web.UI.UserControl

    Public Property DataFile()
        Get
            Return AccessDataSource1.DataFile
        End Get
        Set(value)
            AccessDataSource1.DataFile = value
            AccessDataSource2.DataFile = value
        End Set
    End Property

    Public Event HeatAdvisory(sender As Object, e As EventArgs)

    Protected Sub ddlCities_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlCities.SelectedIndexChanged
        FormView1.DataBind()
        Dim temp As Integer =
            CInt(CType(FormView1.FindControl("TempLabel"), Label).Text)
        If (temp >= 90) Then
            RaiseEvent HeatAdvisory(sender, e)
            FormView1.BackColor = Drawing.Color.Red
        Else
            FormView1.BackColor = Drawing.Color.White
        End If
    End Sub
End Class

﻿
Partial Class Ex1_Links
    Inherits System.Web.UI.UserControl
    Public Property lb1Text As String
        Get
            Return lb1.Text
        End Get
        Set(value As String)
            lb1.Text = value
        End Set
    End Property
    Public Property lb2Text As String
        Get
            Return lb2.Text
        End Get
        Set(value As String)
            lb2.Text = value
        End Set
    End Property
    Public Property lb3Text As String
        Get
            Return lb3.Text
        End Get
        Set(value As String)
            lb3.Text = value
        End Set
    End Property
    Public Property lb4Text As String
        Get
            Return lb4.Text
        End Get
        Set(value As String)
            lb4.Text = value
        End Set
    End Property
    ' urls
    Public Property lb1URL As String
        Get
            Return lb1.PostBackUrl
        End Get
        Set(value As String)
            lb1.PostBackUrl = value
        End Set
    End Property
    Public Property lb2URL As String
        Get
            Return lb2.PostBackUrl
        End Get
        Set(value As String)
            lb2.PostBackUrl = value
        End Set
    End Property
    Public Property lb3URL As String
        Get
            Return lb3.PostBackUrl
        End Get
        Set(value As String)
            lb3.PostBackUrl = value
        End Set
    End Property
    Public Property lb4URL As String
        Get
            Return lb4.PostBackUrl
        End Get
        Set(value As String)
            lb4.PostBackUrl = value
        End Set
    End Property
End Class

﻿Imports Microsoft.VisualBasic
Namespace ASPSampleControls
    Public Class TempConverter
        Inherits CompositeControl

        Protected WithEvents ddlConvert As New DropDownList
        Protected WithEvents txtFah As New TextBox
        Protected WithEvents lblCel As New Label
        Protected WithEvents btnConvert As New Button


        Protected Overrides Sub CreateChildControls()
            MyBase.CreateChildControls()
          
            Controls.Add(New LiteralControl("Please enter a temperature below"))
            Controls.Add(New LiteralControl("<br />"))
            ddlConvert.Items.Add("fahrenheit")
            ddlConvert.Items.Add("celsius")
            ddlConvert.SelectedIndex = 0

            Controls.Add(New LiteralControl("Temp: "))
            Controls.Add(txtFah)
            Controls.Add(New LiteralControl("&nbsp;&nbsp;&nbsp;"))
            Controls.Add(ddlConvert)
            Controls.Add(New LiteralControl("<br />"))
            Controls.Add(lblCel)
            Controls.Add(New LiteralControl("<br />"))
            Controls.Add(btnConvert)
            btnConvert.Text = "Click to convert"
        End Sub

        Private Sub btnConvert_Click(sender As Object, e As System.EventArgs) Handles btnConvert.Click
            Dim temp As Integer = CInt(txtFah.Text)
            Dim converted As Double

            If (ddlConvert.SelectedIndex = 0) Then
                converted = 5.0 / 9.0 * (temp - 32)
                lblCel.Text = "Converts to " & converted.ToString("n1") & "&deg;C"
            Else
                converted = 9.0 / 5.0 * temp + 32
                lblCel.Text = "Converts to " & converted.ToString("n1") & "&deg;F"

            End If



        End Sub
    End Class
End Namespace

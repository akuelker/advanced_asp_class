﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class WeatherService
     Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function GetCities() As ArrayList
        Dim accessDS As New AccessDataSource _
            ("~/App_Data/citytemps.mdb", "select city from cityTemps")
        accessDS.DataSourceMode = SqlDataSourceMode.DataReader
        Dim rdr As System.Data.OleDb.OleDbDataReader
        rdr = accessDS.Select(New DataSourceSelectArguments)
        Dim Cities As New ArrayList()
        Do While rdr.Read()
            Cities.Add(rdr("city"))
        Loop
        Return Cities
    End Function

    <WebMethod()> _
    Public Function GetTemp(city As String) As Integer
        Dim accessDS As New AccessDataSource _
            ("~/App_Data/citytemps.mdb",
            "select temp from cityTemps where city = '" & city & "'")
        accessDS.DataSourceMode = SqlDataSourceMode.DataReader
        Dim rdr As System.Data.OleDb.OleDbDataReader
        rdr = accessDS.Select(New DataSourceSelectArguments)
        rdr.Read()
        Return rdr("temp")
    End Function

End Class
﻿Imports Microsoft.VisualBasic
Imports System.Web.UI.WebControls
Namespace ASPSampleControls
    Public Class CityTemps
        Inherits CompositeControl

        Protected WithEvents ddlCity As New DropDownList
        Protected WithEvents lblTemp As New Label

        Dim accessDS As New AccessDataSource _
             ("~/App_Data/citytemps.mdb", "select * from cityTemps")

        Protected Overrides Sub CreateChildControls()
            MyBase.CreateChildControls()
            ddlCity.DataSource = accessDS
            ddlCity.DataMember = ""
            ddlCity.DataTextField = "City"
            ddlCity.DataValueField = "ID"
            ddlCity.DataBind()
            Controls.Add(ddlCity) ' add control to page
            ddlCity.AutoPostBack = True
            Controls.Add(New LiteralControl("<br />"))
            Controls.Add(lblTemp)
            Controls.Add(New LiteralControl("<br />"))
            lblTemp.Text = "Choose a City"
        End Sub

        Private Sub ddlCity_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlCity.SelectedIndexChanged
            accessDS.SelectCommand = "select temp from citytemps where id = " &
                ddlCity.SelectedValue.ToString
            accessDS.DataFile = "~/App_Data/citytemps.mdb"
            accessDS.DataSourceMode = SqlDataSourceMode.DataReader
            Dim rdr As System.Data.OleDb.OleDbDataReader
            rdr = accessDS.Select(New DataSourceSelectArguments)
            rdr.Read()
            lblTemp.Text = rdr("temp") & "&deg;F"
        End Sub
    End Class
End Namespace
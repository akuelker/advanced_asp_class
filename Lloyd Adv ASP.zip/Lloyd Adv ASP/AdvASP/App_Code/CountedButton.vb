﻿Imports Microsoft.VisualBasic
Namespace ASPSampleControls
    Public Class CountedButton
        Inherits Button

        Protected Overrides Sub OnClick(e As System.EventArgs)
            MyBase.OnClick(e)
            Dim obj As Object = ViewState("count")

            If (obj Is Nothing) Then obj = 0

            obj += 1
            Me.Text = obj & " click(s)"
            ViewState("count") = obj
        End Sub
    End Class
End Namespace
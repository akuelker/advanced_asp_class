﻿Imports Microsoft.VisualBasic
Namespace ASPSampleControls
    Public Class Rectangle
        Inherits WebControl

        Public height As Integer
        Public width As Integer

        Public Property recH As Integer
            Get
                Return height
            End Get
            Set(value As Integer)
                height = value
            End Set
        End Property
        Public Property recW As Integer
            Get
                Return width
            End Get
            Set(value As Integer)
                width = value
            End Set
        End Property

        Public ReadOnly Property Area As Integer
            Get
                Return height * width
            End Get
        End Property

        Protected Overrides Sub Render(writer As System.Web.UI.HtmlTextWriter)
            MyBase.Render(writer)

            If (Area <> 0) Then
                writer.Write("The area of the rectangle is " & Area)
            Else
                writer.Write("Enter valid height and width")
            End If
        End Sub

    End Class
End Namespace

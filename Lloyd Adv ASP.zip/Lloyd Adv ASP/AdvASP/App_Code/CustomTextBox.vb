﻿Imports Microsoft.VisualBasic
Namespace ASPSampleControls
    Public Class CustomTextBox
        Inherits TextBox

        Public Sub style1()
            Me.Text = "Style 1"
            Me.ForeColor = Drawing.Color.Red
            Me.Font.Size = 20
        End Sub
        Public Sub style2()
            Me.Text = "Style 2"
            Me.ForeColor = Drawing.Color.Blue
            Me.Font.Size = 8
        End Sub
    End Class
End Namespace
﻿
Partial Class Ex2_Host
    Inherits System.Web.UI.Page

    Protected Sub btnArea_Click(sender As Object, e As System.EventArgs) Handles btnArea.Click
        rec1.Height = CInt(txtH.Text)
        rec1.Width = CInt(txtW.Text)
    End Sub
End Class

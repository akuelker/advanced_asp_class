﻿
Partial Class UserCOntrolHost
    Inherits System.Web.UI.Page

    Protected Sub ucCityTemp1_HeatAdvisory(sender As Object, e As System.EventArgs) Handles ucCityTemp1.HeatAdvisory
        lblCaution.Text = "Caution! It's Hot!"
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        lblCaution.Text = ""
    End Sub
End Class

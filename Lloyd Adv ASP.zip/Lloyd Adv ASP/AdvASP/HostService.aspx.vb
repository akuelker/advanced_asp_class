﻿
Partial Class HostService
    Inherits System.Web.UI.Page

    Dim proxy As New MyWeather.WeatherService
    Dim proxy2 As New Stocks.StockQuote

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        ddlCities.DataSource = proxy.GetCities()
        If Not IsPostBack Then
            DataBind() 'first time bind cities
        End If
        Dim x As System.AsyncCallback
        MsgBox((proxy2.BeginGetQuote("KOPN", x, "")).ToString)
    End Sub

    Protected Sub ddlCities_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlCities.SelectedIndexChanged
        lblTemp.Text = proxy.GetTemp(ddlCities.SelectedItem.ToString()) & "&deg;F"
    End Sub

End Class

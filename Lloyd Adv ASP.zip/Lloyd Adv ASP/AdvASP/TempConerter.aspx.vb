﻿
Partial Class TempConerter
    Inherits System.Web.UI.Page

    Protected Sub txtTemp_TextChanged(sender As Object, e As System.EventArgs) Handles txtTemp.TextChanged

        Dim proxy As New MyTempConverter.TempConvert
        Dim converted As Integer = proxy.FahrenheitToCelsius(txtTemp.Text)
        lblConverted.Text = converted.ToString("n1")

    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

    End Sub
End Class

﻿
Partial Class DerivedHost
    Inherits System.Web.UI.Page

End Class

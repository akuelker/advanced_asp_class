﻿
Partial Class FullHost
    Inherits System.Web.UI.Page

    Protected Sub btnEnlarge_Click(sender As Object, e As System.EventArgs) Handles btnEnlarge.Click
        st1.Size += 1
        st1.Text = "I just grew!"
    End Sub

    Protected Sub btnShrink_Click(sender As Object, e As System.EventArgs) Handles btnShrink.Click
        st1.Size -= 1
        st1.Text = "I just shrunk!"
    End Sub
End Class

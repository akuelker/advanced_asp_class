﻿
Partial Class CompositeHost
    Inherits System.Web.UI.Page

End Class
